
<?php if(Auth::guest()): ?>
	<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Войти</a></li>
	<li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Регистрация</a></li>
<?php else: ?>
	<li  class="nav-item nav-item-enter"><span>Добро пожаловать, <?php echo e(Auth::user()->getFullNameShort()); ?></span></li>
	<li  class="nav-item">
		<a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
			Выйти
		</a>
		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
			<?php echo e(csrf_field()); ?>

		</form>
	</li>
<?php endif; ?>