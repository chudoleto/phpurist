<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<div class="row">
			<main class="container">
    <div class="intro-background"></div>
    <div class="intro"> 
    </div>
    <div class="img-background"></div>
 
  <div class = "info-string"> Здесь будут новости касающиеся обновлений проекта. </div>
				
		
</main>
			
			
	</div>
	</div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('code'); ?>
	<script>
	
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site.site_container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>