<?php $__env->startSection('content'); ?>

	<?php if($errors->any()): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>
	
	<h1>Файлы</h1>
	
	<form method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" id="id" value="<?php echo e(($item) ? $item->id : ''); ?>">
		
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Файл</label>
					<input name="File_link" id="File_link" value="<?php echo e(old('File_link', null) ? old('File_link') : $item->File_link); ?>" type="text" class="form-control">
				</div>
			</div>
	
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Задача</label>
					<select name="Task_id" id="Task_id" class="custom-select">
						<?php echo App\Task::getSelectFieldOptions($item->Task, old('Task_id', null)); ?>

					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<button type="submit" class="btn btn-primary" name="btn_ok" value="1">Ок</button>
				<button type="submit" class="btn btn-default" name="btn_save" value="1">Сохранить</button>
				<button type="submit" class="btn btn-default" name="btn_cancel" value="1">Отмена</button>
			</div>
		</div>
	</form>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('code'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app.app_container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>