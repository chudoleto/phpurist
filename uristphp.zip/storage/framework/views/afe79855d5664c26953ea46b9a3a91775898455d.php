 <?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-md-center">
		<div class="col-md-6">
			<div class="card">
				<div class="card-body">
					<h4 class="card-title">Авторизация</h4>
					<form class="form-horizontal" method="POST"
						action="<?php echo e(route('login')); ?>">
						<?php echo e(csrf_field()); ?>


						<div
							class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
							<label for="login">Введите логин</label> <input id="login"
								type="text" class="form-control" name="login"
								value="<?php echo e(old('login')); ?>" required autofocus>
							<?php if($errors->has('login')): ?> <span class="help-block"> <strong><?php echo e($errors->first('login')); ?></strong>
							</span> <?php endif; ?>

						</div>

						<div
							class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
							<label for="password">Введите пароль</label> <input id="password"
								type="password" class="form-control" name="password" required>
							<?php if($errors->has('password')): ?> <span class="help-block"> <strong><?php echo e($errors->first('password')); ?></strong>
							</span> <?php endif; ?>

						</div>

						<div class="form-group">
								<div class="checkbox">
									<label> <input type="checkbox" name="remember"<?php echo e(old('remember') ? 'checked' : ''); ?>>
										Запомнить меня
									</label>
								</div>
						</div>

						<div class="form-group">
							<button type="submit" class="btn btn-primary">Войти</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app_container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>