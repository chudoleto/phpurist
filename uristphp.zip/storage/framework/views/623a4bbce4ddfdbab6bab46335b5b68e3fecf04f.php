<?php $__env->startSection('content'); ?>

	<?php if($errors->any()): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>
	
	<h1>Проекты</h1>
	
	<form method="post">
		<?php echo e(csrf_field()); ?>

		
		<div class="row py-2">
			<div class="col-sm-12">
				<button type="submit" class="btn btn-default btn-outline-secondary" name="btn_create" value="1"><i class="fas fa-plus-circle"></i> Создать</button>
			</div>
		</div>
		
		<div class="row py-2 d-none d-sm-flex">
			<div class="col-sm-3 font-weight-bold">Наименование</div>
			<div class="col-sm-2 font-weight-bold">Срок</div>
			<div class="col-sm-3 font-weight-bold">Комментарий</div>
			<div class="col-sm-2 font-weight-bold">Статус</div>
		</div>
		
		<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="row py-2 border-top">
		
			<div class="col-sm-3"> <?php echo e($item->Name); ?> </div>
			<div class="col-sm-2"> <?php echo e($item->Deadline); ?> </div>
			<div class="col-sm-3"> <?php echo e($item->Comment); ?> </div>
			<div class="col-sm-2"> <?php echo e(($item->Status_project) ? $item->Status_project->Description : ''); ?> </div>
			<div class="col-sm-2 text-center">
				<button type="submit" class="btn btn-default btn-outline-secondary" name="btn_edit" value="<?php echo e($item->id); ?>" title="Редактировать"><i class="fas fa-edit"></i></button>
				<button type="submit" class="btn btn-default btn-outline-secondary" name="btn_delete" value="<?php echo e($item->id); ?>" title="Удалить"><i class="fas fa-trash-alt"></i></button>
			</div>
			
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</form>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('code'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app.app_container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>