 <?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-md-center">
		<div class="col-md-6">
			<div class="card">
				<div class="card-body">
					<h4 class="card-title">Регистрация</h4>
					<form class="form-horizontal" method="POST"
						action="<?php echo e(route('register')); ?>">
						<?php echo e(csrf_field()); ?>


						<div
							class="form-group<?php echo e($errors->has('login') ? ' has-error' : ''); ?>">
							<label for="login">Введите логин</label> <input id="login"
								type="text" class="form-control" name="login"
								value="<?php echo e(old('login')); ?>" required> <?php if($errors->has('login')): ?>
							<span class="help-block"> <strong><?php echo e($errors->first('login')); ?></strong>
							</span> <?php endif; ?>
						</div>

						<div
							class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
							<label for="password">Введите пароль</label> <input id="password"
								type="password" class="form-control" name="password" required>
							<?php if($errors->has('password')): ?> <span class="help-block"> <strong><?php echo e($errors->first('password')); ?></strong>
							</span> <?php endif; ?>
						</div>

						<div class="form-group">
							<label for="password-confirm">Подтвердите пароль</label> <input
								id="password-confirm" type="password" class="form-control"
								name="password_confirmation" required>

						</div>

						<div class="form-group">
							<button type="submit" class="btn btn-primary">Регистрация</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app_container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>