<?php $__env->startSection('content'); ?>

	<?php if($errors->any()): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>
	
	<h1>Задача</h1>
	
	<form method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" id="id" value="<?php echo e(($item) ? $item->id : ''); ?>">
		
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Заголовок</label>
					<input name="Header" id="Header" value="<?php echo e(old('Header', null) ? old('Header') : $item->Header); ?>" type="text" class="form-control">
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Описание</label>
					<textarea name="Description" id="Description" class="form-control"><?php echo e(old('Description', null) ? old('Description') : $item->Description); ?></textarea>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Крайний срок</label>
					<input name="Short_deadline" id="Short_deadline" value="<?php echo e(old('Short_deadline', null) ? old('Short_deadline') : $item->Short_deadline); ?>" type="text" class="form-control">
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Начало</label>
					<input name="Start" id="Start" value="<?php echo e(old('Start', null) ? old('Start') : $item->Start); ?>" type="text" class="form-control">
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Конец </label>
					<input name="End" id="End" value="<?php echo e(old('End', null) ? old('End') : $item->End); ?>" type="text" class="form-control">
				</div>
			</div>
				<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Статус</label>
					<input name="Status" id="Status" value="<?php echo e(old('Status', null) ? old('Status') : $item->Status); ?>" type="text" class="form-control">
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Проект</label>
					<select name="Project_id" id="Project_id" class="custom-select">
						<?php echo App\Project::getSelectFieldOptions($item->Project, old('Project_id', null)); ?>

					</select>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Приоритет задачи</label>
					<select name="Priority_task_id" id="Priority_task_id" class="custom-select">
						<?php echo App\Priority_task::getSelectFieldOptions($item->Priority_task, old('Priority_task_id', null)); ?>

					</select>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="name">Статус задачи</label>
					<select name="Status_task_id" id="Status_task_id" class="custom-select">
						<?php echo App\Status_task::getSelectFieldOptions($item->Status_task, old('Status_task_id', null)); ?>

					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<button type="submit" class="btn btn-primary" name="btn_ok" value="1">Ок</button>
				<button type="submit" class="btn btn-default" name="btn_save" value="1">Сохранить</button>
				<button type="submit" class="btn btn-default" name="btn_cancel" value="1">Отмена</button>
			</div>
		</div>
	</form>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('code'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app.app_container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>