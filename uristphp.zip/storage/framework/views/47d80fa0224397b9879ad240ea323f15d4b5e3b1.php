<?php $__env->startSection('head'); ?>
	<?php echo $__env->make('layouts.app.app_style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
	<div class="app mainmenu">
		<nav class="navbar navbar-expand-md navbar-light bg-light"><div class="container">
			<a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#app-navbar-collapse" aria-controls="app-navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
		
			<div class="collapse navbar-collapse" id="app-navbar-collapse">
				<ul class="navbar-nav mr-auto">
					<?php echo $__env->make('layouts.app.elements.app_navbar_left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</ul>
				<ul class="navbar-nav ml-auto">
					<?php echo $__env->make('layouts.app.elements.app_navbar_right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</ul>
			</div>
		</div></nav>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
	<div class="app content">
		<div class="container">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<div class="container"><div class="row">
		<div class="col-sm-6"><i class="glyphicon glyphicon-envelope"></i> <?php echo e(config('mail.from.address', 'info@email.com')); ?></div>
		<div class="col-sm-6 text-right">&copy; <?php echo e(config('app.name', 'Laravel')); ?></div>
	</div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-code'); ?>
	<?php echo $__env->yieldContent('code'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.common.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>