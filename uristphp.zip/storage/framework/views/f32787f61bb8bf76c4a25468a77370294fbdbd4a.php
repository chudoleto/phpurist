<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<base href="<?php echo e(env('APP_URL')); ?>" />
		<title><?php echo e(config('app.name', 'Laravel')); ?></title>
		<link rel="icon" href="<?php echo e(asset('/favicon.ico')); ?>" type="image/x-icon" />
		<link rel="stylesheet" href="https:fonts.googleapis.com/css?family=PT+Sans:400,700&amp;subset=cyrillic" type="text/css">
		<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(asset('/css/fontawesome-all.min.css')); ?>" type="text/css" />
		
		<?php echo $__env->make('layouts.common.frame_style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('head'); ?>
		
	</head>
	<body>
	
	
		
		<div class="page-wrap">
			<div class="content-wrap">
				<?php echo $__env->yieldContent('menu'); ?>
				
				<?php echo $__env->yieldContent('page-content'); ?>
			</div>
			<div class="footer-row">
				<div class="footer-cell">
					<footer>
						<?php echo $__env->yieldContent('footer'); ?>
					</footer>
				</div>
			</div>
		</div>

		
		<script src="<?php echo e(asset('/js/jquery-3.3.1.min.js')); ?>"></script>
		<script src="<?php echo e(asset('/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
		
		<?php echo $__env->make('layouts.common.frame_code', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('page-code'); ?>
		
	</body>
</html>