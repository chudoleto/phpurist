<?php $__env->startSection('head'); ?>
	<?php echo $__env->make('layouts.site.site_style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
	<?php echo $__env->make('layouts.site.elements.site_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
	<?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.site.elements.site_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-code'); ?>
	<?php echo $__env->yieldContent('code'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>