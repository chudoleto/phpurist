<?php if(!Auth::guest()): ?>

	<?php if(Auth::user()->Role->id == 1): ?>
	
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Настройки
			</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="<?php echo e(url('/priority_task')); ?>">Приоритеты задач</a>
				<a class="dropdown-item" href="<?php echo e(url('/status_project')); ?>">Статусы проектов</a>
				<a class="dropdown-item" href="<?php echo e(url('/status_task')); ?>">Статусы задач</a>
				<a class="dropdown-item" href="<?php echo e(url('/role')); ?>">Роли</a>
				<a class="dropdown-item" href="<?php echo e(url('files')); ?>">Файлы</a>
				<a class="dropdown-item" href="<?php echo e(url('/task')); ?>">Задачи</a>
				<a class="dropdown-item" href="<?php echo e(url('/card')); ?>">Карточка</a>
				<a class="dropdown-item" href="<?php echo e(url('/project')); ?>">Проекты</a>
			</div>
		</li>
		
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Администрирование
			</a>
			<div class="dropdown-menu">
				<a class="dropdown-item" href="<?php echo e(url('/servise')); ?>">Сервисы</a>
				<a class="dropdown-item" href="<?php echo e(url('/subdvision')); ?>">Подразделения</a>
				<a class="dropdown-item" href="<?php echo e(url('/user')); ?>">Пользователи</a>
			</div>
		</li>
	<?php endif; ?>
		
	<?php if(Auth::user()->Role->id == 2): ?>
		<?php if(Auth::user()->Subdvision): ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/subdvision/item/' . Auth::user()->Subdvision->id)); ?>">Подразделение</a></li>
		<?php endif; ?>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/user')); ?>">Пользователи</a></li>
	<?php endif; ?>
	
	<?php if(Auth::user()->Role->id == 1 || Auth::user()->Role->id == 2 || Auth::user()->Role->id == 3): ?>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/task')); ?>">Задачи</a></li>
	<?php endif; ?>
	
	
	<?php if(Auth::user()->Role->id == 2 || Auth::user()->Role->id == 3 || Auth::user()->Role->id == 4): ?>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/task')); ?>">Задачи</a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/card')); ?>">Карточка</a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo e(url('files')); ?>">Файлы</a></li>
	<?php endif; ?>
	


<?php endif; ?>