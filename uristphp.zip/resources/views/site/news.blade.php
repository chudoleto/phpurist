@extends('layouts.site.site_container')

@section('content')
	
	<div class="container">
		<div class="row">
			<main class="container">
    <div class="intro-background"></div>
    <div class="intro"> 
    </div>
    <div class="img-background"></div>
 
  <div class = "info-string"> Здесь будут новости касающиеся обновлений проекта. </div>
				
		
</main>
			
			
	</div>
	</div>
	
@endsection

@section('code')
	<script>
	
	</script>
@endsection
