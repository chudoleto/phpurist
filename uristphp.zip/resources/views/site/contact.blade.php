@extends('layouts.site.site_container')

@section('content')
	
	<div class="container">
		<div class="row">
			<main class="container">
    <div class="intro-background"></div>
    <div class="intro"> 
    </div>
    <div class="img-background"></div>
 
    	<div class = "info-string">Связаться с нами можно по электронной почте: chudoleto@ya.ru</div>
				
				
				
			</main>
	  </div>
			
	</div>
	
@endsection

@section('code')
	<script>
	
	</script>
@endsection
