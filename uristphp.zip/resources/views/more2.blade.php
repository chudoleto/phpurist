<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700&amp;subset=cyrillic" rel="stylesheet">
    <title>online</title>
</head>
<body>

<?php 

$a = "10";

?>


<header>
    <nav class="top-menu">
        <a href="index.php" class="nav-menu">Главная</a>
        <a href="#" class="nav-menu">Отзывы</a>
        <a href="index.html" class="logo-head">Новости</a>
        <a href="#" class="nav-menu">Вход</a>
        <a href="ejednevnik.php" class="nav-menu">Регистрация</a>
    </nav>
</header>

<main class="container">
    <div class="intro-background"></div>
    <div class="intro">
        
    </div>
    <div class="img-background"></div>
    
 <form action="">
<a href="tablenew.php" class="adddlink" >Добавить</a>

    <table>
        <thead>
          <tr>
            <th>Номер дела</th>
            <th>Исполнитель</th>
            <th>Ответчик</th>
            <th>Истец</th>
            <th>В каком суде находится</th>
            <th>Стадия рассмотрения</th>
            <th>Аппеляционный период</th>
            <th>Штрафы</th>
            <th>РИП</th>
            <th>Краткая информация</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong><?php echo $a; ?></strong></td>
            <td>fdsfsd</td>
            <td><strong>324</strong></td>
            <td>sdfdsfsd</td>
            <td>15</td>
            <td><strong>wet fd sxds<strong></td>
            <td>fdsd dgher</td>
            <td><strong>dfdsf werwe bvcb</strong></td>
            <td>15</td>
            <td><strong>5gdfg3 sda<strong></td>
          </tr>
         
         
        </tbody>
      </table>
</form>
    

    
 
</main>


<footer>
    <div class="footer-container">
    <div class="visit">
        <h2>что-то вставлю </h2>
    </div>
    <div class="visit">
        <a class="twitter">
            <a href="#"></a>
         </a>
         <a class="facebook">
            <a href="#"></a>
         </a>
         <a class="youtube">
            <a href="#"></a>
         </a>
    </div>
    <div class="visit">
        <div class="logo">
            <span>Website by</span>
        <a href="#"></a>
        </div>
    </div>
    </div>
</footer>

</body>
</html>