@extends('layouts.app.app_container')

@section('content')
		<div class="row">
			<div class="col text-center">
				
			</div>
		</div>
	
@endsection

@section('code')
@endsection