<div class="container"><div class="row"><div class="col-sm-12">
	<div class="footer-container">
		<div class="visit">
			<h2>#LawyerOnline+</h2>
		</div>
		<div class="visit">
			<a class="twitter"> <a href="https://twitter.com/chilli_vill"></a>
<!-- 		    </a><a class="facebook"> <a href="#"></a> -->
<!-- 			</a> <a class="youtube"> <a href="#"></a>--} -->
			</a>
		</div>
		<div class="visit">
			<div class="logo">
				<span>Website by ChudoLeto</span> <a href="#"></a>
			</div>
		</div>
	</div>
</div></div></div>